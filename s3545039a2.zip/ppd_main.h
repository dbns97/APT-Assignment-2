/***********************************************************************
 * COSC1076 - Advanced Programming Techniques
 * Semester 2 2016 Assignment #2
 * Full Name        : Drew Nuttall-Smith
 * Student Number   : s3545039
 * Course Code      : COSC1076
 * Program Code     : BP096
 * Start up code provided by Paul Miller
 * Some codes are adopted here with permission by an anonymous author
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "ppd_stock.h"
#include "ppd_coin.h"
#include "ppd_shared.h"
#ifndef PPD_MAIN
#define PPD_MAIN

/**
 * This function gets the command line arguments and
 * saves them in the system
 **/
BOOLEAN get_params(struct ppd_system* system, int argc, char** argv);

#endif
